package com.example.loadbooking.model;

public enum LoadStatus {
    POSTED, BOOKED, CANCELLED
}
