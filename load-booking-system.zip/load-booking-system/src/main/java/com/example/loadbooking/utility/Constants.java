package com.example.loadbooking.utility;

public class Constants {

}
