package com.example.loadbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoadBookingSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoadBookingSystemApplication.class, args);
        System.out.println("Load Booking System is up and running...");
    }
}
