package com.example.loadbooking.model;

public enum BookingStatus {
    PENDING, ACCEPTED, REJECTED
}
