package com.example.loadbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
